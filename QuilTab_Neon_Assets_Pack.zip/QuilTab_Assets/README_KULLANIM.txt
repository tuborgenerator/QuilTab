QUILTAB — NEON PURPLE ASSET PACK

İçerik: 15 şeffaf PNG ikon (logo, home, users, user, eye, globe, zap,
settings, map-pin, shield, search, rocket, star, chevron-right, crosshair).

Bu paketteki ikonlar bu paket için çizilmiş özgün görsellerdir. Ek olarak
açık lisanslı çevrimiçi ikon kütüphanesi:
https://lucide.dev/
Kaynak kodu/lisans: https://github.com/lucide-icons/lucide

ROBLOX STUDIO KULLANIMI
1. PNG'leri Creator Dashboard > Development Items bölümünden Image olarak yükle.
2. Roblox'un verdiği her görsel ID'sini kopyala.
3. LocalScript içinde ImageLabel/ImageButton için:
   Image = "rbxassetid://BURAYA_ID"
4. Bilgisayarındaki PNG dosyası, Roblox'a yüklenmeden oyunda doğrudan kullanılamaz.

Örnek:
local icon = Instance.new("ImageLabel")
icon.BackgroundTransparency = 1
icon.Size = UDim2.fromOffset(24, 24)
icon.Image = "rbxassetid://BURAYA_ID"
icon.Parent = someFrame

Not: Bu ZIP Roblox'a otomatik yükleme yapmaz. Her görseli Roblox'a yükleyip ID'sini
koda eklemen gerekir. Üçüncü taraf logolarını kullanırken lisans/marka koşullarını
kontrol et.
